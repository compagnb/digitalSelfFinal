#pragma once

#include "ofMain.h"

class testApp : public ofBaseApp{
	
	public:
		void setup();
		void update();
		void draw();

		void keyPressed  (int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
        string ofxGetSerialString(ofSerial &serial, char until);
		string ofxTrimStringRight(string str);
        string ofxTrimStringLeft(string str);
        string ofxTrimString(string str);
        //vector<string>ans;
        vector <string> numbersAsStrings;// vectpr of information split up
        vector <int> numbersVector; //vector of ints
    
		ofTrueTypeFont		font;

		bool		bSendSerialMessage;			// a flag for sending serial
		char		bytesRead[3];				// data from serial, we will be trying to read 3
		char		bytesReadString[4];			// a string needs a null terminator, so we need 3 + 1 bytes
		int			nBytesRead;					// how much did we read?
		int			nTimesRead;					// how many times did we read?
		float		readTime,signal,attention,meditation,delta,theta,lowAlpha,highAlpha,lowBeta,highBeta,lowGamma,highGamma;					// when did we last read?
		
		ofSerial	serial;
        string str;
        string fullPacket;
    
    //Function for generating audio
	void audioOut( float * input, int bufferSize, int nChannels );
    //Function for generating audio
	void audioOut2( float * input, int bufferSize, int nChannels );
    
	ofSoundStream soundStream;	//Object for sound output setup
    ofSoundStream soundStream2;	//Object for sound output setup
    
    //User-changing parameters
	float userFreq;				//Frequency
	float userPwm;				//PWM-value
    
    float userFreq2;				//Frequency
	float userPwm2;				//PWM-value
    
	//Parameters, used during synthesis
	float freq;					//Current frequency
	float pwm;					//Current PWM-value
	float phase;				//Phase of the wave
    
    float freq2;					//Current frequency
	float pwm2;					//Current PWM-value
	float phase2;				//Phase of the wave
    
	//Buffer for rendering last generated audio buffer
	vector<float> buf;
    vector<float> buf2;
    
};

