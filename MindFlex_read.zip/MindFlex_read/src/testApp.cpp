#include "testApp.h"

int bufSize = 512;		//Sound card buffer size
int sampleRate = 44100;	//Sound sample rate
float volume = 0.1;		//Output volume



//--------------------------------------------------------------
void testApp::setup(){
	ofSetVerticalSync(true);
	
	bSendSerialMessage = false;
	ofBackground(255);
	ofSetLogLevel(OF_LOG_VERBOSE);
	
	serial.listDevices();
	vector <ofSerialDeviceInfo> deviceList = serial.getDeviceList();
	
	// this should be set to whatever com port your serial device is connected to.
	// (ie, COM4 on a pc, /dev/tty.... on linux, /dev/tty... on a mac)
	// arduino users check in arduino app....
	int baud = 9600;
    serial.setup(0, baud); //open the first device
	//serial.setup("COM4", baud); // windows example
    //serial.setup("/dev/tty.usbmodem411", baud); // mac osx example
	//serial.setup("/dev/ttyUSB0", baud); //linux example
	
	nTimesRead = 0;
	nBytesRead = 0;
	readTime = 0;
	memset(bytesReadString, 0, 4);
    str = "";
    fullPacket = "";
    
    userFreq = 100.0;		//Some initial frequency
	userPwm = 0.5;			//Some initial PWM-value
    
    
	freq = userFreq;
	pwm = userPwm;
	phase = 0;
	buf.resize( bufSize );
    
  
    
	//Start the sound output
	soundStream.setup( this, 2, 0, sampleRate, bufSize, 4 );
   
    
}

//--------------------------------------------------------------
void testApp::update(){
    
    do {
        str = ofxGetSerialString(serial,'\n'); //read until end of line
        if (str=="") continue;
       numbersAsStrings=ofSplitString(str, ",");
        
        //cout <<"" <<ans[2]<<endl;
        
        // cout << str;
        
        
        
        //fullPacket+=str;
    } while (str!="");
    //while (str!="");
    //cout << fullPacket <<endl;
    
    //use fullPacket for below...
    //figure out how take this string and split it into an 11-cell array with the individual values inside of it
    
     for( int i = 0; i < numbersAsStrings.size(); i++){
         //separates number into channel
                 if (i == 0){
                     signal = ofToInt(numbersAsStrings[i]);
                 } else if (i == 1){
                     attention = ofToInt(numbersAsStrings[i]);
                     //userFreq = ofMap( meditation, 0, ofGetWidth(), 1, 2000);
                     //userFreq =ofMap(meditation, 0, 100, 1, 100);
                     userFreq = ofMap(meditation, 0, 100, 1, 80);
                 } else if (i == 2){
                     meditation = ofToInt(numbersAsStrings[i]);
                     //userPwm = ofMap( attention, 0, ofGetHeight(), 1, 2000);
                     //userFreq2 = ofMap(attention, 0, 100, 1, 100);
                 } else if (i == 3){
                     delta = ofToInt(numbersAsStrings[i]);
                 } else if (i == 4){
                     theta = ofToInt(numbersAsStrings[i]);
                 } else if (i == 5){
                     lowAlpha = ofToInt(numbersAsStrings[i]);
                 } else if (i == 6){
                     highAlpha = ofToInt(numbersAsStrings[i]);
                 } else if (i == 7){
                     lowBeta = ofToInt(numbersAsStrings[i]);
                 } else if (i == 8){
                     highBeta = ofToInt(numbersAsStrings[i]);
                 } else if (i == 9){
                     lowGamma = ofToInt(numbersAsStrings[i]);
                 } else if (i == 10){
                     highGamma = ofToInt(numbersAsStrings[i]);
                 }

     }
    
    fullPacket = "";
    

}


//--------------------------------------------------------------
void testApp::draw(){
    
    ofSetColor(signal/2,meditation/2,attention/2);
    ofFill();
    ofCircle(200,200,25);
    cout << userPwm<<endl;
    cout << meditation <<endl;
    //
    ofBackground( 255, 255, 255 );	//Set the background color
	//Draw the buffer values
	ofSetColor( 0, 0, 0 );
	for (int i=0; i<bufSize-1; i++) {
		ofLine( i, 50 - buf[i]*50, (i+1), 50 - buf[i+1]*50 );
    }
    //Draw the buffer values
	ofSetColor( 200, 0, 0 );
	for (int i=0; i<bufSize-1; i++) {
		ofLine( i, 250 - buf[i]*50, (i+1), 250 - buf[i+1]*50 );
    }
}

//--------------------------------------------------------------
void testApp::audioOut( float * output, int bufferSize, int nChannels ){
	//Fill output buffer,
	//and also move freq to userFreq and pwm to userPWM slowly
	for (int i=0; i<bufferSize; i++) {
		//freq smoothly reaches userFreq
		freq += ( userFreq - freq ) * 0.001;
		//pwm smoothly reaches userPwm
		pwm += ( userPwm - pwm ) * 0.001;
        
		//Change phase, and push it into [0, 1] range
		phase += freq / sampleRate;
        //phase += meditation / sampleRate;
		phase = fmodf( phase, 1.0 );
        
		//Calculate the output audio sample value
		//Instead of 1 and 0 we use 1 and -1 output values
		//for the sound wave to be symmetrical along y-axe
		float v = ( phase < pwm ) ? 1.0 : -1.0;
        
		//Set the computed value to the left and the right
		//channels of output buffer,
		//also using global volume value defined above
		output[ i*2 ] = output[ i*2 + 1 ] = v * volume;
        
		//Set the value to buffer buf, used for rendering
		//on the screen
		//Note: bufferSize can occasionally differ from bufSize
		if ( i < bufSize ) {
			buf[ i ] = v;
		}
	}
}
//--------------------------------------------------------------
string testApp::ofxGetSerialString(ofSerial &serial, char until) {
    static string str;
    stringstream ss;
    char ch;
    int ttl=1000;
    while ((ch=serial.readByte())>0 && ttl-->0 && ch!=until) {
        ss << ch;
    }
    
    str+=ss.str();
    if (ch==until) {
        string tmp=str;
        str="";
        return ofxTrimString(tmp);
    } else {
        return "";
    }
    
}
//--------------------------------------------------------------
string testApp::ofxTrimStringRight(string str) {
    size_t endpos = str.find_last_not_of(" \t\r\n");
    return (string::npos != endpos) ? str.substr( 0, endpos+1) : str;
}

// trim trailing spaces//--------------------------------------------------------------
string testApp::ofxTrimStringLeft(string str) {
    size_t startpos = str.find_first_not_of(" \t\r\n");
    return (string::npos != startpos) ? str.substr(startpos) : str;
}
//--------------------------------------------------------------
string testApp::ofxTrimString(string str) {
    return ofxTrimStringLeft(ofxTrimStringRight(str));;
}

//--------------------------------------------------------------
void testApp::keyPressed  (int key){
	
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){
	
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y){
    //userFreq = ofMap( x, 0, ofGetWidth(), 1, 2000 );
	//userPwm = ofMap( y, 0, ofGetHeight(), 0, 2000 );
	
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
	
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
	
}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){
	
}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){
	
}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 
	
}

