#include "testApp.h"

float mass = 0.007;    //Mass of point
float g = 9.8;         //Gravity force
float time0, time02, time03;           //Time value, used for time step computing
ofPoint pos, vel, pos2, vel2, pos3, vel3;      //Ball position and velocity

//--------------------------------------------------------------
void testApp::setup(){
	ofSetVerticalSync(true);
	
	bSendSerialMessage = false;
	ofBackground(255);
	ofSetLogLevel(OF_LOG_VERBOSE);
	
	serial.listDevices();
	vector <ofSerialDeviceInfo> deviceList = serial.getDeviceList();
	
	// this should be set to whatever com port your serial device is connected to.
	// (ie, COM4 on a pc, /dev/tty.... on linux, /dev/tty... on a mac)
	// arduino users check in arduino app....
	int baud = 9600;
    serial.setup(0, baud); //open the first device
	//serial.setup("COM4", baud); // windows example
    //serial.setup("/dev/tty.usbmodem411", baud); // mac osx example
	//serial.setup("/dev/ttyUSB0", baud); //linux example
	
	nTimesRead = 0;
	nBytesRead = 0;
	readTime = 0;
	memset(bytesReadString, 0, 4);
    str = "";
    fullPacket = "";
    
    //Set up sound sample
	sound.loadSound( "bounce.wav" );  //Load sound sample
	sound.setMultiPlay( true );       //Set multiplay mode
    
	//Model setup
	time0 = ofGetElapsedTimef();    //Get current time
	pos = ofPoint( ofGetWidth() / 2, 100 ); //Ball's initial position
	vel = ofPoint( 0, 0 );  //Initial velocity
    pos2 = ofPoint( ofGetWidth() / 2, 100 ); //Ball's initial position
	vel2 = ofPoint( 0, 0 );  //Initial velocity
    
	//Set up background to not clear each frame
	ofSetBackgroundAuto( false );
	ofBackground( 255, 255, 255 );    //Clear background to white

}

//--------------------------------------------------------------
void testApp::update(){
    
    do {
        str = ofxGetSerialString(serial,'\n'); //read until end of line
        if (str=="") continue;
       numbersAsStrings=ofSplitString(str, ",");
        
        //cout <<"" <<ans[2]<<endl;
        
        // cout << str;
        
        
        
        //fullPacket+=str;
    } while (str!="");
    //cout << fullPacket <<endl;
    
    //use fullPacket for below...
    //figure out how take this string and split it into an 11-cell array with the individual values inside of it
    
     for( int i = 0; i < numbersAsStrings.size(); i++){
         //separates number into channel
                 if (i == 0){
                     signal = ofToInt(numbersAsStrings[i]);
                 } else if (i == 1){
                     attention = ofToInt(numbersAsStrings[i]);
                     //userFreq = ofMap( meditation, 0, ofGetWidth(), 1, 2000);
                     //userFreq =ofMap(meditation, 0, 100, 1, 100);
                    // userFreq = ofMap(meditation, 0, 100, 1, 80);
                 } else if (i == 2){
                     meditation = ofToInt(numbersAsStrings[i]);
                     //userPwm = ofMap( attention, 0, ofGetHeight(), 1, 2000);
                    // userFreq2 = ofMap(attention, 0, 100, 1, 100);
                 } else if (i == 3){
                     delta = ofToInt(numbersAsStrings[i]);
                 } else if (i == 4){
                     theta = ofToInt(numbersAsStrings[i]);
                 } else if (i == 5){
                     lowAlpha = ofToInt(numbersAsStrings[i]);
                 } else if (i == 6){
                     highAlpha = ofToInt(numbersAsStrings[i]);
                 } else if (i == 7){
                     lowBeta = ofToInt(numbersAsStrings[i]);
                 } else if (i == 8){
                     highBeta = ofToInt(numbersAsStrings[i]);
                 } else if (i == 9){
                     lowGamma = ofToInt(numbersAsStrings[i]);
                 } else if (i == 10){
                     highGamma = ofToInt(numbersAsStrings[i]);
                 }

     }
    
    fullPacket = "";
    //Update ball position and check if it is bounced
	bool bounced = updateBall();
	if ( bounced ) {
		//Start sample playing
		sound.play();
		//Set play speed, in dependence of x
		float speed = ofMap( attention, 0, ofGetWidth(), 0.2, 2 );
		sound.setSpeed( speed );
	}
    //Update ball position and check if it is bounced
	bool bounced2 = updateBall2();
	if ( bounced2 ) {
		//Start sample playing
		sound.play();
		//Set play speed, in dependence of x
		float speed2 = ofMap( meditation, 0, ofGetWidth(), 0.2, 2 );
		sound.setSpeed( speed2 );
	//Update sound engine
	ofSoundUpdate();
    }
    //Update ball position and check if it is bounced
	bool bounced3 = updateBall3();
	if ( bounced3 ) {
		//Start sample playing
		sound.play();
		//Set play speed, in dependence of x
		float speed3 = ofMap(highAlpha, 0, ofGetWidth(), 0.2, 2 );
		sound.setSpeed( speed3 );
        //Update sound engine
        ofSoundUpdate();
    }

}


//--------------------------------------------------------------
void testApp::draw(){
    //
	float bottom = 300.0; //The floor position on the screen
	//Draw the floor line in black color
	ofSetColor( 0, 0, 0 );
	ofLine( 0, bottom, ofGetWidth(), bottom );
	//Draw the ball in blue color
	ofSetColor( 0, 0, 255 );
	ofFill();
	ofCircle( pos3.x, bottom - pos3.y, 3 );

    //Draw the ball in red color
	ofSetColor( 255, 0, 0 );
	ofFill();
	ofCircle( pos.x, bottom - pos.y, 3 );
    
    //Draw the ball in blue color
	ofSetColor( 0, 255, 0 );
	ofFill();
	ofCircle( pos2.x, bottom - pos2.y, 3 );
    
//    //Draw the ball in blue color
//	ofSetColor( 0, 0, 255 );
//	ofFill();
//	ofCircle( pos3.x, bottom - pos3.y, 3 );
//    
    
}

//--------------------------------------------------------------
bool testApp::updateBall() {
	bool bounced = false;
    
	//Compute dt
	float time = ofGetElapsedTimef();
	float dt = ofClamp( time - time0, 0, 0.1 );
	time0 = time;
    
	//Compute gravity force acceleration
	//using the second Newton's law
	ofPoint acc( 0, -g/mass );
    
	//Change velocity and position using Euler's method
	vel += acc * dt;
	pos += vel * dt;
    
	//Check if the ball bounced off floor
	if ( pos.y < 0 ) {
		//Elastic bounce with momentum conservation
		pos.y = -pos.y;
		vel.y = -vel.y;
		//Set random velocity by x axe in range [-300, 500]
		vel.x = attention;
		bounced = true;
	}
    
	//Check if the ball is out of screen
	if ( pos.x < 0 ) { pos.x += ofGetWidth(); }
	if ( pos.x > ofGetWidth() ) { pos.x -= ofGetWidth(); }
	return bounced;
}
//--------------------------------------------------------------
bool testApp::updateBall2() {
	bool bounced2 = false;
    
	//Compute dt
	float time2 = ofGetElapsedTimef();
	float dt2 = ofClamp( time2 - time02, 0, 0.1 );
	time02 = time2;
    
	//Compute gravity force acceleration
	//using the second Newton's law
	ofPoint acc2( 0, -g/mass );
    
	//Change velocity and position using Euler's method
	vel2 += acc2 * dt2;
	pos2 += vel2 * dt2;
    
	//Check if the ball bounced off floor
	if ( pos2.y < 0 ) {
		//Elastic bounce with momentum conservation
		pos2.y = -pos2.y;
		vel2.y = -vel2.y;
		//Set random velocity by x axe in range [-300, 500]
		vel2.x = meditation;
		bounced2 = true;
	}
    
	//Check if the ball is out of screen
	if ( pos2.x < 0 ) { pos2.x += ofGetWidth(); }
	if ( pos2.x > ofGetWidth() ) { pos2.x -= ofGetWidth(); }
	return bounced2;
}
//--------------------------------------------------------------
bool testApp::updateBall3() {
	bool bounced3 = false;
    
	//Compute dt
	float time3 = ofGetElapsedTimef();
	float dt3 = ofClamp( time3 - time03, 0, 0.1 );
	time03 = time3;
    
	//Compute gravity force acceleration
	//using the second Newton's law
	ofPoint acc3( 0, -g/mass );
    
	//Change velocity and position using Euler's method
	vel3 += acc3 * dt3;
	pos3 += vel3 * dt3;
    
	//Check if the ball bounced off floor
	if ( pos3.y < 0 ) {
		//Elastic bounce with momentum conservation
		pos3.y = -pos3.y;
		vel3.y = -vel3.y;
		//Set random velocity by x axe in range [-300, 500]
		vel3.x = highAlpha;
		bounced3 = true;
	}
    
	//Check if the ball is out of screen
	if ( pos3.x < 0 ) { pos3.x += ofGetWidth(); }
	if ( pos3.x > ofGetWidth() ) { pos3.x -= ofGetWidth(); }
	return bounced3;
}


//--------------------------------------------------------------
string testApp::ofxGetSerialString(ofSerial &serial, char until) {
    static string str;
    stringstream ss;
    char ch;
    int ttl=1000;
    while ((ch=serial.readByte())>0 && ttl-->0 && ch!=until) {
        ss << ch;
    }
    
    str+=ss.str();
    if (ch==until) {
        string tmp=str;
        str="";
        return ofxTrimString(tmp);
    } else {
        return "";
    }
    
}
//--------------------------------------------------------------
string testApp::ofxTrimStringRight(string str) {
    size_t endpos = str.find_last_not_of(" \t\r\n");
    return (string::npos != endpos) ? str.substr( 0, endpos+1) : str;
}

// trim trailing spaces//--------------------------------------------------------------
string testApp::ofxTrimStringLeft(string str) {
    size_t startpos = str.find_first_not_of(" \t\r\n");
    return (string::npos != startpos) ? str.substr(startpos) : str;
}
//--------------------------------------------------------------
string testApp::ofxTrimString(string str) {
    return ofxTrimStringLeft(ofxTrimStringRight(str));;
}

//--------------------------------------------------------------
void testApp::keyPressed  (int key){
	
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){
	
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y){
    //userFreq = ofMap( x, 0, ofGetWidth(), 1, 2000 );
	//userPwm = ofMap( y, 0, ofGetHeight(), 0, 2000 );
	
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
	
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
	
}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){
	
}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){
	
}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){
}

